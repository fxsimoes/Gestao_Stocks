package io.altar.jseproject.test;

import java.util.Scanner;

import io.altar.jseproject.textinterface.TextInterface;

public class Test {
	
	public static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args){

		TextInterface.mainMenu();
    	
	}
}